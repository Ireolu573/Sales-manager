import { useState, useMemo } from 'react'
import { supabase } from '@/integrations/supabase/client'
import type { Sale, StockRecord } from '@/lib/types'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Download, BarChart3 } from 'lucide-react'
import { useQuery } from '@tanstack/react-query'

// 🧩 Our new modular child components
import AnalyticsCards from '@/components/analytics/AnalyticsCards'
import AnalyticsCharts from '@/components/analytics/AnalyticsCharts'

interface Props {
  userId: string
  tenantId: string
  isAdmin: boolean
}

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

export default function Analytics({ userId, tenantId, isAdmin }: Props) {
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth())
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear())
  const [filterMode, setFilterMode] = useState<'month' | 'range'>('month')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [exporting, setExporting] = useState(false)

  // 🔄 Fetch sales data
  const { data: sales = [], isLoading: loadingSales } = useQuery({
    queryKey: ['sales', tenantId, userId, isAdmin],
    queryFn: async () => {
      const query = isAdmin
        ? supabase.from('sales').select('*').eq('tenant_id', tenantId).order('sale_date', { ascending: false })
        : supabase.from('sales').select('*').eq('user_id', userId).eq('tenant_id', tenantId).order('sale_date', { ascending: false })
      const { data, error } = await query
      if (error) throw error
      return (data || []) as Sale[]
    },
    enabled: !!tenantId,
  })

  // 🔄 Fetch stock records
  const { data: stockRecords = [], isLoading: loadingStock } = useQuery({
    queryKey: ['stock', tenantId, userId, isAdmin],
    queryFn: async () => {
      const query = isAdmin
        ? supabase.from('stock_records').select('*').eq('tenant_id', tenantId).order('stock_date', { ascending: false })
        : supabase.from('stock_records').select('*').eq('user_id', userId).eq('tenant_id', tenantId).order('stock_date', { ascending: false })
      const { data, error } = await query
      if (error) throw error
      return (data || []) as StockRecord[]
    },
    enabled: !!tenantId,
  })

  const loading = loadingSales || loadingStock

  const inRange = (dateStr: string) => {
    if (filterMode === 'month') {
      const d = new Date(dateStr)
      return d.getMonth() === selectedMonth && d.getFullYear() === selectedYear
    }
    const from = dateFrom || '2000-01-01'
    const to = dateTo || '2099-12-31'
    return dateStr >= from && dateStr <= to
  }

  const monthSales = useMemo(() => sales.filter(s => inRange(s.sale_date)), [sales, filterMode, selectedMonth, selectedYear, dateFrom, dateTo])
  const monthStock = useMemo(() => stockRecords.filter(s => inRange(s.stock_date)), [stockRecords, filterMode, selectedMonth, selectedYear, dateFrom, dateTo])

  // 🧮 Summary calculations
  const totalRevenue = monthSales.reduce((sum, s) => sum + Number(s.total_amount), 0)
  const totalQty = monthSales.reduce((sum, s) => sum + Number(s.quantity), 0)
  const totalStockCost = monthStock.reduce((sum, s) => sum + Number(s.total_cost), 0)
  const estimatedProfit = totalRevenue - totalStockCost

  const cashRevenue = monthSales.filter(s => s.payment_method === 'cash').reduce((s, c) => s + Number(c.total_amount), 0)
  const transferRevenue = monthSales.filter(s => s.payment_method === 'transfer').reduce((s, c) => s + Number(c.total_amount), 0)
  const posRevenue = monthSales.filter(s => s.payment_method === 'pos').reduce((s, c) => s + Number(c.total_amount), 0)
  const creditRevenue = monthSales.filter(s => s.payment_method === 'credit').reduce((s, c) => s + Number(c.total_amount), 0)
  const outstandingCredit = monthSales.filter(s => s.payment_method === 'credit' && !s.paid_at).reduce((s, c) => s + Number(c.total_amount), 0)

  const paymentPieData = [
    { name: 'Cash', value: cashRevenue, color: 'hsl(142, 71%, 45%)' },
    { name: 'Transfer', value: transferRevenue, color: 'hsl(217, 91%, 60%)' },
    { name: 'POS', value: posRevenue, color: 'hsl(280, 65%, 60%)' },
    { name: 'Credit', value: creditRevenue, color: 'hsl(38, 92%, 50%)' },
  ].filter(d => d.value > 0)

  const topProducts = useMemo(() => {
    const byItem: Record<string, { qty: number; revenue: number }> = {}
    monthSales.forEach(s => {
      if (!byItem[s.item_name]) byItem[s.item_name] = { qty: 0, revenue: 0 }
      byItem[s.item_name].qty += Number(s.quantity)
      byItem[s.item_name].revenue += Number(s.total_amount)
    })
    return Object.entries(byItem)
      .map(([name, v]) => ({ name, revenue: v.revenue, qty: v.qty }))
      .sort((a, b) => b.revenue - a.revenue)
  }, [monthSales])

  const maxRevenue = topProducts[0]?.revenue || 1

  const dailyData = useMemo(() => {
    const byDay: Record<number, number> = {}
    monthSales.forEach(s => {
      const d = new Date(s.sale_date).getDate()
      byDay[d] = (byDay[d] || 0) + Number(s.total_amount)
    })
    return Object.entries(byDay)
      .map(([day, revenue]) => ({ day: `${day}`, revenue }))
      .sort((a, b) => Number(a.day) - Number(b.day))
  }, [monthSales])

  // 📥 Full Excel Export mapping
  const exportXLSX = async (all: boolean) => {
    setExporting(true)
    try {
      const XLSX = await import('xlsx')
      const salesData = all ? sales : monthSales
      const stockData = all ? stockRecords : monthStock
      const period = all ? String(selectedYear) : (filterMode === 'month' ? `${MONTHS[selectedMonth]}-${selectedYear}` : `${dateFrom}-to-${dateTo}`)

      const salesObjects = salesData.map(s => ({
        'Date': s.sale_date,
        'Time': s.created_at ? new Date(s.created_at).toLocaleTimeString('en-NG', { hour: '2-digit', minute: '2-digit', hour12: true }) : '',
        'Item': s.item_name,
        'Quantity': Number(s.quantity),
        'Total (N)': Number(s.total_amount),
        'Payment': s.payment_method,
      }))

      const stockObjects = stockData.map(s => ({
        'Date': s.stock_date,
        'Item': s.item_name,
        'Quantity': Number(s.quantity),
        'Total Cost (N)': Number(s.total_cost),
      }))

      const wb = XLSX.utils.book_new()

      const salesSheet = XLSX.utils.json_to_sheet(salesObjects)
      XLSX.utils.book_append_sheet(wb, salesSheet, 'Sales')

      const stockSheet = XLSX.utils.json_to_sheet(stockObjects)
      XLSX.utils.book_append_sheet(wb, stockSheet, 'Stock Records')

      XLSX.writeFile(wb, `report-${period}.xlsx`, { bookType: 'xlsx', compression: true })
    } catch (err) {
      console.error('Export failed:', err)
    } finally {
      setExporting(false)
    }
  }

  const years = Array.from(new Set([
    ...sales.map(s => new Date(s.sale_date).getFullYear()),
    ...stockRecords.map(s => new Date(s.stock_date).getFullYear()),
    selectedYear,
  ])).sort().reverse()

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <div className="w-8 h-8 rounded-full border-4 border-muted animate-spin border-t-primary" />
      </div>
    )
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <BarChart3 className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h2 className="font-bold text-foreground text-lg">Analytics</h2>
          <p className="text-sm text-muted-foreground">Business performance insights</p>
        </div>
      </div>

      {/* 📅 Filters Section */}
      <Card className="border-border/50 shadow-sm">
        <CardContent className="p-4 space-y-3">
          <div className="flex bg-muted rounded-lg p-0.5 w-fit">
            <button onClick={() => setFilterMode('month')}
              className={`text-xs font-medium px-3 py-1.5 rounded-md transition-all ${filterMode === 'month' ? 'bg-card text-primary shadow-sm' : 'text-muted-foreground'}`}>
              By month
            </button>
            <button onClick={() => setFilterMode('range')}
              className={`text-xs font-medium px-3 py-1.5 rounded-md transition-all ${filterMode === 'range' ? 'bg-card text-primary shadow-sm' : 'text-muted-foreground'}`}>
              Date range
            </button>
          </div>

          {filterMode === 'month' ? (
            <div className="flex items-center gap-2 flex-wrap">
              <Select value={String(selectedMonth)} onValueChange={v => setSelectedMonth(Number(v))}>
                <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
                <SelectContent>{MONTHS.map((m, i) => <SelectItem key={m} value={String(i)}>{m}</SelectItem>)}</SelectContent>
              </Select>
              <Select value={String(selectedYear)} onValueChange={v => setSelectedYear(Number(v))}>
                <SelectTrigger className="w-24"><SelectValue /></SelectTrigger>
                <SelectContent>{years.map(y => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          ) : (
            <div className="flex items-center gap-2 flex-wrap">
              <Input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="w-auto" />
              <span className="text-muted-foreground text-sm">to</span>
              <Input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="w-auto" />
            </div>
          )}

          <div className="flex gap-2 flex-wrap">
            <Button onClick={() => exportXLSX(false)} size="sm" className="gap-1.5" disabled={exporting}>
              <Download className="w-3.5 h-3.5" />
              {exporting ? 'Exporting...' : 'Export Period (.xlsx)'}
            </Button>
            <Button onClick={() => exportXLSX(true)} size="sm" variant="secondary" className="gap-1.5" disabled={exporting}>
              <Download className="w-3.5 h-3.5" />
              {exporting ? 'Exporting...' : 'Full Year (.xlsx)'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* 🧩 Our clean, modular components rendering perfectly! */}
      <AnalyticsCards 
        totalRevenue={totalRevenue}
        totalQty={totalQty}
        totalStockCost={totalStockCost}
        estimatedProfit={estimatedProfit}
        outstandingCredit={outstandingCredit}
      />

      <AnalyticsCharts 
        topProducts={topProducts}
        maxRevenue={maxRevenue}
        dailyData={dailyData}
        paymentPieData={paymentPieData}
      />
    </div>
  )
}
